package com.example.myproject.entities;

public enum TypeCours {
    COLLECTIF_ENFANT,COLLECTIF_ADULTE,PARTICULIER ;
}
