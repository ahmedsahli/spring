package com.example.myproject.entities;

public enum Couleur {
    rouge,vert,bleu,noir ;
}
