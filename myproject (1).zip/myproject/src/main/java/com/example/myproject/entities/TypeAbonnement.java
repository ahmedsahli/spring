package com.example.myproject.entities;

public enum TypeAbonnement {
    ANNUEL,SEMESTRIEL,MENSUEL ;
}
