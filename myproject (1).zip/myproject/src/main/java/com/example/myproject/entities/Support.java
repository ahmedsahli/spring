package com.example.myproject.entities;

public enum Support {
    SKI,SNOWBOARD ;
}
